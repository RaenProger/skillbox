<template>
    <h1>Страница не найдена</h1>
</template>

<script>
export default {

};
</script>
