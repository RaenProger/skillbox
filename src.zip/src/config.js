export const API_BASE_URL = 'https://vue-study.skillbox.cc';
