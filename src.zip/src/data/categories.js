export default [
    {
id: 1,
title: 'Зубные щетки',
    },
    {
id: 2,
title: 'Телефоны',
    },
    {
id: 3,
title: 'Спортинвентарь',
    },
    {
id: 4,
title: 'Радионяни',
    },
    {
id: 5,
title: 'Наушники',
    },
];
