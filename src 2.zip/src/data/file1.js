/* export const message = 'Hello vue';

export const message2 = 'Hello again'; */
