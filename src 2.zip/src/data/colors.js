export default [
  {
    id: 1,
    name: 'blue',
    code: '#135180',
  },
  {
    id: 2,
    name: 'white',
    code: '#ffffff',
  },
  {
    id: 3,
    name: 'yellow',
    code: '#ffbe15',
  },
  {
    id: 4,
    name: 'grey',
    code: '#939393',
  },
  {
    id: 5,
    name: 'black',
    code: '#222222',
  },
  {
    id: 6,
    name: 'green',
    code: '#8be000',
  },
];
