/* const notification = function (wordOne, wordTwo) {
  alert(wordOne, wordTwo);
};

export default notification; */
